<?php
// This is an example of config.php
$dbhost = 'localhost';
$dbuser = '[YOUR DATABASE USERNAME HERE]';
$dbpass = '[YOUR PASSWORD HERE]';
$dbname = 'adventureworks';
?>
